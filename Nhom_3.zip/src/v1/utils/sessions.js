// session.js
const sessions = [];
module.exports = sessions;
